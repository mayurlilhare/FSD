import { useEffect, useState } from 'react';
import './App.css';
import Myblock from './Block';
import axios from 'axios';

function App() {
 
  const arr = [0,1,2,3,4,5,6,7,8]
  const [board, setBoard] = useState([])
  const[botMove, setBotMove] = useState('')
  const[winMessage, setWinMessage] = useState('')

  function resetGame() {
    axios.get('http://localhost:8080/reset')
    window.location.reload()
  }

  
  function sendRequest(e) {
    console.log(e)
    axios.post('http://localhost:8080/makePlayerMove',{"p":1,"move": e})
    .then((resp)=>{
      console.log(resp)
      if(resp.data.message === 'Bot Chance'){
        sendBotRequest()
      }
      else if(resp.data.message === 'Player won'){
        setWinMessage('Player won')
      }
      else if(resp.data.message === 'Game Over'){
        setWinMessage('Game Over')
      }
    })
    .then((err)=>{
      console.log(err)
    })
  }

  function sendBotRequest() {
    axios.get('http://localhost:8080/makeBotMove')
    .then((resp)=>{
      console.log("resp: ",resp)
      if(resp.data.message === 'Player Chance'){
        setBotMove(resp.data.move)
        board.push(resp.data.move)
      }
      else if(resp.data.message === 'Bot won'){
        setBotMove(resp.data.move)
        board.push(resp.data.move)
        setTimeout(() => {
          setWinMessage('Bot won')
        }, 500);
      }
      else if(resp.data.message === 'Game Over'){
        setWinMessage('Game Over')
      }
    })
    .catch((err)=>{
      console.log("err: ",err)
    })
  }
  return (
    <>
    <h1>{winMessage}</h1>
    <button onClick={()=>resetGame()}>reset</button>
      <div className="App">
      {
        arr.map((e)=>{
          return(
            <Myblock key={e} id={e} sendRequestCall={()=>sendRequest(e)} botMove={botMove === e?botMove:''} board={board}/>
          )
        })
      }
    </div>
    </>
  );
}

export default App;
