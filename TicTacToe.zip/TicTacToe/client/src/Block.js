
import { useEffect, useState } from 'react';
import classes from './block.module.css'

function Block({id, sendRequestCall, botMove, board}) {
  const [myboard, setBoard] = useState([])
    const [myvalue, setMyValue] = useState('')
    const [playerMove, setPlayerMove] = useState(false)
    const [robotMove, setRobotMove] = useState(false)
    useEffect(()=>{
        handleBotMove()
    },[botMove])
    function handleBotMove() {
        let tempArr = [...board]
        setBoard(tempArr)
    }
    function sendMyRequest(){
        if(!playerMove){
            // console.log("hii", id)
            // setMyValue('_/')
            // setIsDisabled(true)
            setPlayerMove(true)
            sendRequestCall(id)
        }
    }
    return (
        <div id={id} className={(playerMove ? classes.disabledBolck : ( myboard.indexOf(id) !== -1 ? classes.botBolck : classes.block)) } onClick={()=>sendMyRequest()} >
        {myvalue}
      </div>
    );
}
export default Block;
