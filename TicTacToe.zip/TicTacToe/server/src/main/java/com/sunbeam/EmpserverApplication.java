package com.sunbeam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;

import com.sunbeam.controllers.Game;

@SpringBootApplication(exclude = SecurityAutoConfiguration.class)
public class EmpserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpserverApplication.class, args);
		
	}

}
