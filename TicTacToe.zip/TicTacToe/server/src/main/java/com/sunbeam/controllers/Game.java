package com.sunbeam.controllers;

public class Game {
	private static int[][] gameBoard =new int[3][3];
	public static void resetBoard(){
		gameBoard = new int[3][3];
		
	}
	
	public int playerMove(int p, int row, int col) {
		
			gameBoard[row][col] = p;
			int result = checkWin(p, row, col);
			showBoard();
			return result;
		
	}
	
	public boolean checkInvalidity(int p, int row, int col) {
		
		if(row < 0 || row > 2 || col < 0 || col > 2)
		{   
//			return "Invalid Move";
			System.out.println(p+" Out of index move");
			return false;
		}
		else if(gameBoard[row][col] != 0){
//			return "Invalid block to move";
			System.out.println(p+" Block already filled");
			return false;
		}
		else {
//			return "valid";
			return true;
		}
	}
	public int checkWin(int p, int row, int col) {
		int rowSum = 0, colSum=0, digSum=0, revDigSUm=0;
		for(int i=0; i<3; i++) {
			rowSum += gameBoard[row][i];
			colSum += gameBoard[i][col];
			digSum += gameBoard[i][i];
			revDigSUm += gameBoard[i][3-i-1];
		}
		System.out.println("player "+p+" "+rowSum+"" +colSum+"" + digSum+"" + revDigSUm);
		if(3 == Math.abs(rowSum) 
				|| 3 == Math.abs(colSum) 
				|| 3 == Math.abs(digSum) 
				|| 3 == Math.abs(revDigSUm) )
			{ 
			return p;
			}
		else {
			return 0;
			}
	}
	public void showBoard() {
		for(int i=0; i<3; i++) {
			for(int j=0;j<3; j++) {
				System.out.print(gameBoard[i][j]);
			}
			System.out.println("");
		}
		System.out.println("\\\\\\\\\\\\");
	}
}
