package com.sunbeam.controllers;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
public class TicTacToeApplicationController {

	Logger logger = LoggerFactory.getLogger(TicTacToeApplicationController.class);
	private static int count = 0;
	private Game g = new Game();
	static int result = 0;
	public TicTacToeApplicationController() {
		logger.info("Inside TicTacToe Application Controller");
	}
	
	@GetMapping("/reset")
	public ResponseEntity<?> resetGame() {
		System.out.println("reset game");
		count = 0;
		Game.resetBoard();
		return new ResponseEntity<>( "reset", HttpStatus.OK);
	}
	
	@PostMapping("/makePlayerMove")
	public ResponseEntity<?> makePlayerMove(@RequestBody Map< String, String> map){
		
		responseDto respDto = null;
		int p = Integer.parseInt(map.get("p"));
		int move =Integer.parseInt(map.get("move")); 
		int row = move/3;
		int col = move%3;
//		System.out.println(row +" "+col);
		int checkWin = playerMove(p, row, col);
		
		if(checkWin == p) {
			System.out.println("Player 1 won");
			respDto = new responseDto("Player won", (row*3)+col);
			return new ResponseEntity<>(respDto, HttpStatus.OK);
		}
		else if(checkWin == 0) {
			System.out.println("Invalid Player Move");
			respDto = new responseDto("Invalid Move", (row*3)+col);
			return new ResponseEntity<>(respDto, HttpStatus.OK);
		}
		else {
			if(count == 9) {
				System.out.println("Game Over");
				respDto = new responseDto("Game Over", (row*3)+col);
				return new ResponseEntity<>(respDto, HttpStatus.OK);
			}
			System.out.println("Bot Chance");
			respDto = new responseDto("Bot Chance", (row*3)+col);
			return new ResponseEntity<>(respDto, HttpStatus.OK);
		}
	}
	
	@GetMapping("/makeBotMove")
	public ResponseEntity<?> makeBotMove(){
		
		responseDto respDto = null;
		int p=-1;
		int row = ((int)(Math.random()*100))%3;
		int col = ((int)(Math.random()*100))%3;
//		System.out.println(row +" "+col);
		int checkWin = playerMove(p, row, col);
		
		if(checkWin == p) {
			System.out.println("Bot won");
			respDto = new responseDto("Bot won", (row*3)+col);
			return new ResponseEntity<>(respDto, HttpStatus.OK);
		}
		else if(checkWin == 0) {
			System.out.println("Invalid Bot Move");
			
			return makeBotMove();
		}
		else {
			if(count == 9) {
				System.out.println("Game Over");
				respDto = new responseDto("Game Over", (row*3)+col);
				return new ResponseEntity<>(respDto, HttpStatus.OK);
			}
			System.out.println("Player Chance");
			respDto = new responseDto("Player Chance", (row*3)+col);
			return new ResponseEntity<>(respDto, HttpStatus.OK);
		}
	}
	
	public int playerMove(int p, int row, int col) {
		boolean result = g.checkInvalidity(p, row, col);
		
		if(result) {
			count++;
			int win = g.playerMove(p, row, col);
			if(win == p) {
//				System.out.println("Player Win");
				return p;
			}else {
				return 10;
			}
		}
		else {
//			System.out.println("Block Already Filled");
			return 0;
		}
	}
	
}

