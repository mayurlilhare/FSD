package com.sunbeam.controllers;

public class responseDto {
	String message;
	int move;
	public responseDto(String message, int move) {
		super();
		this.message = message;
		this.move = move;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getmove() {
		return move;
	}
	public void setmove(int move) {
		this.move = move;
	}
	
	
}
